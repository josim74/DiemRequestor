package com.biswajitbanik.Diem.HomeCategory.ViewModel;

/**
 * Created by Omar Faruq on 5/15/2018.
 */

public interface PopularViewModel  {


    void showPopularModels();

    void showRecentJobs();

    void openTaskActivity();
}
