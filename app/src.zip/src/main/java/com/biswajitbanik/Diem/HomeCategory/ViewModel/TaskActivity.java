package com.biswajitbanik.Diem.HomeCategory.ViewModel;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.codility.introsilder.R;

public class TaskActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_task);
    }
}
