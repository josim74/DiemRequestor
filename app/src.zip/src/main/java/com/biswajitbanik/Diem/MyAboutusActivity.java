package com.biswajitbanik.Diem;


import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;


public class MyAboutusActivity extends AppCompatActivity {



    private String[] mAboutus;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);


    }
}
