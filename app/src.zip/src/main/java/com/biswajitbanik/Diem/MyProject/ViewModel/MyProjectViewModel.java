package com.biswajitbanik.Diem.MyProject.ViewModel;

/**
 * Created by Omar Faruq on 5/19/2018.
 */

public interface MyProjectViewModel {

    void showList();
}
