package com.biswajitbanik.Diem.Task.Repository;

import java.util.List;

/**
 * Created by Omar Faruq on 5/22/2018.
 */

public interface QuestionDBCallback {
    public void getQuestion(List<QuestionModel> questionModels);
}
