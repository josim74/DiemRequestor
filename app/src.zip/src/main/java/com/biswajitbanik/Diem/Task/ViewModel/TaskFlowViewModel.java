package com.biswajitbanik.Diem.Task.ViewModel;

import android.support.v4.app.Fragment;

/**
 * Created by Omar Faruq on 5/24/2018.
 */

public interface TaskFlowViewModel {

}
